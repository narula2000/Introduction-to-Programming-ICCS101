# Assigment 01 Task 02
# Name: VIkrom Narula
# Time spent: 8:00 min

a=input("Enter your name:")
print(a)
print("Hi,"+a)
b=input("Enter your year of birth:")
print("Your age is "+str(2018-int(b)))